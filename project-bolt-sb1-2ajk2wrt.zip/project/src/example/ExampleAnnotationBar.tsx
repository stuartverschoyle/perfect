import { ArrowLeft, Eye } from 'lucide-react';
import { useState } from 'react';

export default function ExampleAnnotationBar() {
  const [showAnnotations, setShowAnnotations] = useState(true);

  return (
    <>
      <div className="fixed top-0 left-0 right-0 z-[100] bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between">
          <a
            href="#guide"
            className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <ArrowLeft size={16} />
            <span className="hidden sm:inline">Back to SEO Guide</span>
            <span className="sm:hidden">Guide</span>
          </a>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 hidden sm:inline">SEO annotations</span>
            <button
              onClick={() => {
                setShowAnnotations(!showAnnotations);
                document.documentElement.classList.toggle('hide-annotations', showAnnotations);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                showAnnotations
                  ? 'bg-teal-100 dark:bg-teal-500/20 text-teal-600 dark:text-teal-400 border border-teal-500/30'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
              }`}
            >
              <Eye size={13} />
              {showAnnotations ? 'Annotations On' : 'Annotations Off'}
            </button>
          </div>
        </div>
      </div>
      <div className="h-11" />
    </>
  );
}
