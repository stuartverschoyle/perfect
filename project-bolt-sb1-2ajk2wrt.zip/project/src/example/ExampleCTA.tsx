import { ArrowRight, Globe, Zap, BookOpen } from 'lucide-react';
import SeoAnnotation from './SeoAnnotation';

export default function ExampleCTA() {
  return (
    <section id="resources" className="relative py-24 sm:py-32 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative grid lg:grid-cols-2 gap-16">
          <SeoAnnotation label="Conversion" position="top-left">
            <p className="font-semibold text-slate-900 dark:text-white mb-1">Bottom-of-Page CTA Section</p>
            <p>Every page should end with a clear conversion path. Users who scroll to the bottom are engaged -- don't let them leave without an action.</p>
            <p className="mt-1.5">This section combines a lead magnet (primary conversion) with free tool links (secondary conversion) for users who prefer different engagement levels.</p>
            <p className="mt-1.5">The form uses {'<form>'} with proper {'<label>'} tags -- important for both accessibility and for Google to understand the page's purpose.</p>
            <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">Pages with forms convert 5x better than pages that only link to a contact page.</p>
          </SeoAnnotation>

          <div>
            <span className="text-xs text-slate-900/30 dark:text-white/30 tracking-[0.3em] uppercase mb-3 block">Free Tools</span>
            <h2 className="text-3xl sm:text-4xl font-light text-slate-900 dark:text-white tracking-tight mb-6">
              Resources to <span className="font-semibold">Get Started</span>
            </h2>
            <p className="text-slate-900/50 dark:text-white/50 text-base font-light leading-relaxed mb-10">
              You don't need expensive tools to start optimising. These free resources will help you audit your site, identify issues, and track improvements over time.
            </p>

            <div className="space-y-6">
              {[
                { icon: Globe, label: 'Google Search Console', detail: 'See how Google views your site. Free, essential, non-negotiable.' },
                { icon: Zap, label: 'PageSpeed Insights', detail: 'Test any URL for Core Web Vitals. Lab and field data combined.' },
                { icon: BookOpen, label: 'Google Rich Results Test', detail: 'Validate your schema markup and see which rich features you qualify for.' },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-teal-500/5 border border-teal-500/10 flex items-center justify-center shrink-0">
                    <item.icon size={16} className="text-teal-600/60 dark:text-teal-400/60" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-slate-900 dark:text-white">{item.label}</div>
                    <div className="text-xs text-slate-900/30 dark:text-white/30">{item.detail}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <SeoAnnotation label="Form SEO" position="top-right">
              <p className="font-semibold text-slate-900 dark:text-white mb-1">Forms & SEO</p>
              <p>Forms don't directly impact rankings, but they're critical for conversion rate -- a ranking factor in Google's quality rater guidelines.</p>
              <p className="mt-1.5">Use proper {'<label>'} elements linked to inputs via htmlFor/id. This helps accessibility and allows Google to understand form purpose.</p>
              <p className="mt-1.5">Lead magnets (free guides, checklists, tools) convert better than "contact us" forms because they offer immediate value.</p>
            </SeoAnnotation>

            <form className="bg-slate-50/[0.5] dark:bg-white/[0.02] border border-slate-200/[0.6] dark:border-white/[0.06] rounded-xl p-6 sm:p-8 space-y-5">
              <div className="text-center mb-4">
                <div className="w-12 h-12 rounded-xl bg-teal-100 dark:bg-teal-500/10 border border-teal-500/20 flex items-center justify-center mx-auto mb-3">
                  <BookOpen size={20} className="text-teal-600 dark:text-teal-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Free Website Audit Checklist</h3>
                <p className="text-xs text-slate-900/40 dark:text-white/40 mt-1">44 checks across technical SEO, content, and performance</p>
              </div>

              <div>
                <label htmlFor="name" className="block text-xs text-slate-900/40 dark:text-white/40 uppercase tracking-wider mb-2">Your Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="w-full bg-transparent border-b border-slate-200 dark:border-white/10 pb-2 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:border-teal-400/40 focus:outline-none transition-colors"
                  placeholder="Jane Smith"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-xs text-slate-900/40 dark:text-white/40 uppercase tracking-wider mb-2">Email Address</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  className="w-full bg-transparent border-b border-slate-200 dark:border-white/10 pb-2 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:border-teal-400/40 focus:outline-none transition-colors"
                  placeholder="jane@company.com"
                />
              </div>

              <div>
                <label htmlFor="website" className="block text-xs text-slate-900/40 dark:text-white/40 uppercase tracking-wider mb-2">Website URL</label>
                <input
                  type="url"
                  id="website"
                  name="website"
                  className="w-full bg-transparent border-b border-slate-200 dark:border-white/10 pb-2 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-white/20 focus:border-teal-400/40 focus:outline-none transition-colors"
                  placeholder="https://yoursite.com"
                />
              </div>

              <button
                type="submit"
                className="group w-full flex items-center justify-center gap-3 px-6 py-4 bg-teal-500 text-white text-xs font-semibold uppercase tracking-widest hover:bg-teal-400 transition-colors mt-4 rounded-lg"
              >
                Get Your Free Checklist
                <ArrowRight size={14} className="group-hover:translate-x-0.5 transition-transform" />
              </button>

              <p className="text-[10px] text-slate-900/20 dark:text-white/20 text-center leading-relaxed">
                No spam. Unsubscribe any time. We respect your inbox.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
