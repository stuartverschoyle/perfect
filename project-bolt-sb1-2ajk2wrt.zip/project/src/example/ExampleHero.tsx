import { ArrowRight, BookOpen } from 'lucide-react';
import SeoAnnotation from './SeoAnnotation';

export default function ExampleHero() {
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden" aria-label="Hero">
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
          alt="Computer screen displaying website code and performance metrics for website optimisation"
          width={1920}
          height={1080}
          loading="eager"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/70 to-black/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-white dark:from-[#0a0a0a] via-transparent to-transparent" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <SeoAnnotation label="Hero Image" position="top-right">
          <p className="font-semibold text-slate-900 dark:text-white mb-1">Hero Image SEO</p>
          <p>This image uses <span className="text-teal-600 dark:text-teal-400">loading="eager"</span> because it's above the fold. All other images use lazy loading.</p>
          <p className="mt-1.5">The alt text is descriptive and keyword-rich: "Computer screen displaying website code and performance metrics for website optimisation".</p>
          <p className="mt-1.5">Image is served at 1920px width with auto-compression. WebP/AVIF formats via CDN would reduce size by 30-50%.</p>
          <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">File naming: "website-optimisation-performance-metrics.webp" -- descriptive, hyphenated, keyword-rich.</p>
        </SeoAnnotation>

        <SeoAnnotation label="H1" position="top-left">
          <p className="font-semibold text-slate-900 dark:text-white mb-1">The H1 Tag</p>
          <p>Every page must have exactly <span className="text-teal-600 dark:text-teal-400">one H1 tag</span>. It's the most important on-page SEO element after the title tag.</p>
          <p className="mt-1.5">This H1 targets the primary keyword "How to Optimise a Website" -- matching the exact search query users type into Google.</p>
          <p className="mt-1.5">The H1 closely matches the page's title tag to reinforce relevance signals to search engines.</p>
          <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">H1 is 46 characters -- well under the 60-character recommendation.</p>
        </SeoAnnotation>

        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-teal-500/20 bg-teal-500/5 backdrop-blur-sm mb-6">
            <div className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse" />
            <span className="text-xs text-teal-300/80 tracking-wider uppercase">Updated April 2026</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light text-slate-900 dark:text-white leading-[1.1] mb-6 tracking-tight">
            How to Optimise
            <br />
            <span className="font-semibold">a Website</span>
          </h1>

          <p className="text-lg sm:text-xl text-slate-900/60 dark:text-white/60 leading-relaxed mb-10 max-w-lg font-light">
            A complete, step-by-step guide to improving your website's speed, search rankings, and user experience. From technical SEO to content strategy, learn what actually moves the needle.
          </p>

          <SeoAnnotation label="CTA" position="inline">
            <p className="font-semibold text-slate-900 dark:text-white mb-1">Call-to-Action SEO</p>
            <p>Primary CTAs should use action verbs and be above the fold. "Start the Guide" is far better than "Submit" or "Click Here".</p>
            <p className="mt-1.5">The secondary CTA (Read the Checklist) provides an alternative path for users who want a quick reference rather than the full guide.</p>
            <p className="mt-1.5">Using {'<a>'} tags with descriptive text for CTAs helps search engines understand the page's conversion goals.</p>
            <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">Limit to 1-2 CTAs per viewport to avoid decision fatigue.</p>
          </SeoAnnotation>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-4">
            <a
              href="#why-optimise"
              className="group inline-flex items-center gap-3 px-8 py-4 bg-teal-500 text-white text-sm font-semibold uppercase tracking-widest hover:bg-teal-400 transition-all rounded-lg"
            >
              Start the Guide
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#resources" className="group inline-flex items-center gap-3 text-sm text-slate-900/60 dark:text-white/60 hover:text-slate-900 dark:hover:text-white transition-colors uppercase tracking-widest font-medium">
              <span className="w-10 h-10 rounded-full border border-slate-300 dark:border-white/20 flex items-center justify-center group-hover:border-teal-400/40 transition-colors">
                <BookOpen size={14} />
              </span>
              Read the Checklist
            </a>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 right-4 sm:right-8 hidden lg:flex flex-col items-center gap-3">
        <span className="text-[10px] text-slate-900/30 dark:text-white/30 tracking-widest uppercase" style={{ writingMode: 'vertical-rl' }}>Scroll</span>
        <div className="w-px h-16 bg-gradient-to-b from-white/0 via-white/20 to-white/0" />
      </div>
    </section>
  );
}
