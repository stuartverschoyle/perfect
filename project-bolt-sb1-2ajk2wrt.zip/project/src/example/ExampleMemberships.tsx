import { ArrowRight, Gauge, FileSearch, Code } from 'lucide-react';
import SeoAnnotation from './SeoAnnotation';

const pillars = [
  {
    title: 'Technical SEO',
    subtitle: 'Foundation',
    description: 'The structural and technical elements that help search engines crawl, index, and understand your website. Without a solid technical foundation, even great content won\'t rank.',
    features: ['Page speed and Core Web Vitals', 'Mobile responsiveness', 'Crawlability and indexing', 'Structured data markup'],
    impact: 'High Impact',
    icon: Code,
  },
  {
    title: 'On-Page SEO',
    subtitle: 'Content & Structure',
    description: 'Optimising individual pages so that search engines understand your content and users find what they need. This includes titles, headings, meta descriptions, and copy quality.',
    features: ['Title tags and meta descriptions', 'Heading hierarchy (H1-H6)', 'Internal linking strategy', 'Image alt text and compression'],
    impact: 'High Impact',
    icon: FileSearch,
  },
  {
    title: 'Performance',
    subtitle: 'Speed & UX',
    description: 'Google uses Core Web Vitals as a ranking factor. A fast, smooth website keeps visitors engaged and reduces bounce rates -- both direct signals that influence rankings.',
    features: ['Largest Contentful Paint (LCP)', 'Interaction to Next Paint (INP)', 'Cumulative Layout Shift (CLS)', 'Time to First Byte (TTFB)'],
    impact: 'Growing Impact',
    icon: Gauge,
  },
];

export default function ExampleMemberships() {
  return (
    <section id="why-optimise" className="relative py-24 sm:py-32 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative mb-16">
          <SeoAnnotation label="H2" position="inline">
            <p className="font-semibold text-slate-900 dark:text-white mb-1">Section Headings (H2)</p>
            <p>Each major page section uses an H2. These tell Google the page's sub-topics and often appear in search result snippets.</p>
            <p className="mt-1.5">The heading "Why Website Optimisation Matters" includes the target keyword naturally while being compelling for users.</p>
            <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">H2 tags are the second most important heading signal after H1. Include secondary keywords naturally.</p>
          </SeoAnnotation>

          <span className="block text-xs text-slate-900/30 dark:text-white/30 tracking-[0.3em] uppercase mb-3 mt-3">The fundamentals</span>
          <h2 className="text-3xl sm:text-4xl font-light text-slate-900 dark:text-white tracking-tight">
            Why Website Optimisation <span className="font-semibold">Matters</span>
          </h2>
          <p className="mt-4 text-slate-900/50 dark:text-white/50 max-w-xl text-lg font-light leading-relaxed">
            Website optimisation improves how search engines understand your content and how users experience your site. It rests on three pillars.
          </p>
        </div>

        <div className="relative grid md:grid-cols-3 gap-6">
          <SeoAnnotation label="Content Structure" position="top-right">
            <p className="font-semibold text-slate-900 dark:text-white mb-1">Card-Based Content</p>
            <p>Repeating content blocks (like these cards) should use consistent structure: heading, description, features list.</p>
            <p className="mt-1.5">Each card uses an H3 tag for its title, maintaining the heading hierarchy: {'H1 (page) > H2 (section) > H3 (card)'}.</p>
            <p className="mt-1.5">Lists are marked up with {'<ul>'} and {'<li>'} tags which Google can parse for featured snippets.</p>
            <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">This structure can trigger Google's "list" featured snippet format.</p>
          </SeoAnnotation>

          {pillars.map((p) => (
            <article
              key={p.title}
              className="group relative bg-slate-50/[0.5] dark:bg-white/[0.02] border border-slate-200/[0.6] dark:border-white/[0.06] rounded-xl p-8 hover:bg-slate-100/[0.5] dark:hover:bg-white/[0.04] hover:border-teal-500/20 transition-all duration-500"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-teal-100 dark:bg-teal-500/10 flex items-center justify-center border border-teal-500/20">
                  <p.icon size={18} className="text-teal-600 dark:text-teal-400" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-900/30 dark:text-white/30 tracking-[0.2em] uppercase block">{p.subtitle}</span>
                  <h3 className="text-xl font-semibold text-slate-900 dark:text-white">{p.title}</h3>
                </div>
              </div>

              <p className="text-sm text-slate-900/40 dark:text-white/40 leading-relaxed mb-6">{p.description}</p>

              <ul className="space-y-2.5 mb-8">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2.5 text-sm text-slate-900/60 dark:text-white/60">
                    <div className="w-1 h-1 rounded-full bg-teal-400/50" />
                    {f}
                  </li>
                ))}
              </ul>

              <div className="flex items-center justify-between pt-6 border-t border-slate-200 dark:border-white/5">
                <span className="text-xs text-teal-600/60 dark:text-teal-400/60 tracking-wider uppercase">{p.impact}</span>
                <a
                  href="#steps"
                  className="flex items-center gap-1.5 text-xs text-slate-900/50 dark:text-white/50 hover:text-teal-600 dark:hover:text-teal-400 transition-colors tracking-wider uppercase font-medium group-hover:gap-2.5"
                >
                  Learn How <ArrowRight size={13} className="transition-transform group-hover:translate-x-0.5" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
