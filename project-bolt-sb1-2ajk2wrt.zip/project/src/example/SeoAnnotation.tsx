import { useState, useRef, useEffect } from 'react';
import { Info, X } from 'lucide-react';

interface SeoAnnotationProps {
  label: string;
  children: React.ReactNode;
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left' | 'inline';
}

export default function SeoAnnotation({ label, children, position = 'top-right' }: SeoAnnotationProps) {
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  const positionClasses: Record<string, string> = {
    'top-right': 'top-2 right-2',
    'top-left': 'top-2 left-2',
    'bottom-right': 'bottom-2 right-2',
    'bottom-left': 'bottom-2 left-2',
    'inline': 'relative',
  };

  const panelPosition: Record<string, string> = {
    'top-right': 'right-0 top-full mt-2',
    'top-left': 'left-0 top-full mt-2',
    'bottom-right': 'right-0 bottom-full mb-2',
    'bottom-left': 'left-0 bottom-full mb-2',
    'inline': 'left-0 top-full mt-2',
  };

  return (
    <span className={`annotation-marker ${position === 'inline' ? 'relative inline-flex' : `absolute z-50 ${positionClasses[position]}`}`}>
      <button
        onClick={() => setOpen(!open)}
        className="group flex items-center gap-1 px-2 py-1 rounded-full bg-teal-500/90 hover:bg-teal-400 text-[10px] font-bold uppercase tracking-wider text-white shadow-lg shadow-teal-500/20 transition-all hover:scale-105"
        aria-label={`SEO info: ${label}`}
      >
        <Info size={11} strokeWidth={3} />
        <span className="hidden sm:inline">{label}</span>
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-[60] md:hidden" onClick={() => setOpen(false)} />
          <div
            ref={panelRef}
            className={`absolute z-[70] w-72 sm:w-80 rounded-xl bg-white dark:bg-slate-900 border border-teal-500/30 shadow-2xl shadow-teal-500/10 ${panelPosition[position]}`}
          >
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-200 dark:border-slate-700/50">
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-teal-400" />
                <span className="text-xs font-bold text-teal-600 dark:text-teal-400 uppercase tracking-wider">{label}</span>
              </div>
              <button onClick={() => setOpen(false)} className="text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors">
                <X size={14} />
              </button>
            </div>
            <div className="px-4 py-3 text-xs text-slate-600 dark:text-slate-300 leading-relaxed space-y-2">
              {children}
            </div>
          </div>
        </>
      )}
    </span>
  );
}
