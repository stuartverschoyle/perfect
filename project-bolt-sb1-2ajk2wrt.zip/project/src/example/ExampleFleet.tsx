import { ArrowRight, Clock, TrendingUp, Zap } from 'lucide-react';
import SeoAnnotation from './SeoAnnotation';

const steps = [
  {
    name: 'Audit Your Current Site',
    category: 'Step 1',
    image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800&h=500&fit=crop',
    alt: 'Website performance audit dashboard showing analytics data and site health metrics',
    time: '2-4 hours',
    difficulty: 'Beginner',
    tools: 'Screaming Frog, PageSpeed Insights',
  },
  {
    name: 'Fix Technical Issues',
    category: 'Step 2',
    image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=800&h=500&fit=crop',
    alt: 'Developer fixing website technical issues and broken links on computer screen',
    time: '1-2 days',
    difficulty: 'Intermediate',
    tools: 'Search Console, Ahrefs',
  },
  {
    name: 'Optimise Content & On-Page',
    category: 'Step 3',
    image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800&h=500&fit=crop',
    alt: 'Content strategist reviewing on-page SEO elements including title tags and meta descriptions',
    time: 'Ongoing',
    difficulty: 'Intermediate',
    tools: 'Surfer SEO, Hemingway Editor',
  },
];

export default function ExampleFleet() {
  return (
    <section id="steps" className="relative py-24 sm:py-32 bg-slate-50 dark:bg-[#070707] scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
          <div>
            <span className="text-xs text-slate-900/30 dark:text-white/30 tracking-[0.3em] uppercase mb-3 block">The Process</span>
            <h2 className="text-3xl sm:text-4xl font-light text-slate-900 dark:text-white tracking-tight">
              Step-by-Step <span className="font-semibold">Optimisation</span>
            </h2>
            <p className="mt-4 text-slate-900/40 dark:text-white/40 max-w-lg text-base font-light leading-relaxed">
              Website optimisation follows a proven sequence: audit, fix, optimise, measure, repeat. Here is how to approach each phase.
            </p>
          </div>
          <a href="#resources" className="flex items-center gap-2 text-xs text-teal-600/60 dark:text-teal-400/60 hover:text-teal-600 dark:hover:text-teal-400 transition-colors tracking-wider uppercase font-medium shrink-0">
            Download Full Checklist <ArrowRight size={14} />
          </a>
        </div>

        <div className="relative grid md:grid-cols-3 gap-6">
          <SeoAnnotation label="Images" position="top-right">
            <p className="font-semibold text-slate-900 dark:text-white mb-1">Image SEO in Practice</p>
            <p>Each step image demonstrates proper SEO:</p>
            <ul className="mt-1.5 space-y-1">
              <li>- <span className="text-teal-600 dark:text-teal-400">Alt text</span> describes the image content and includes relevant keywords naturally</li>
              <li>- <span className="text-teal-600 dark:text-teal-400">loading="lazy"</span> for below-fold images (saves bandwidth, improves Core Web Vitals)</li>
              <li>- <span className="text-teal-600 dark:text-teal-400">width/height</span> attributes prevent layout shift (CLS)</li>
              <li>- Images sized at 800px for cards -- never serve 4000px images for 400px slots</li>
            </ul>
            <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">Ideal file names: "website-audit-performance-dashboard.webp"</p>
          </SeoAnnotation>

          {steps.map((step) => (
            <article key={step.name} className="group">
              <div className="relative overflow-hidden rounded-xl mb-4">
                <img
                  src={step.image}
                  alt={step.alt}
                  width={800}
                  height={500}
                  loading="lazy"
                  className="w-full aspect-[8/5] object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <span className="absolute top-3 left-3 px-2.5 py-1 bg-teal-500/90 backdrop-blur-sm text-[10px] text-white font-semibold tracking-wider uppercase rounded-md">
                  {step.category}
                </span>
              </div>

              <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-3">{step.name}</h3>

              <div className="grid grid-cols-3 gap-3">
                {[
                  { icon: Clock, label: 'Time', value: step.time },
                  { icon: TrendingUp, label: 'Difficulty', value: step.difficulty },
                  { icon: Zap, label: 'Tools', value: step.tools },
                ].map((stat) => (
                  <div key={stat.label} className="text-center p-2.5 bg-slate-100 dark:bg-white/[0.02] rounded-lg border border-slate-200 dark:border-white/[0.04]">
                    <stat.icon size={14} className="mx-auto text-teal-600/40 dark:text-teal-400/40 mb-1.5" />
                    <div className="text-xs font-medium text-slate-900/80 dark:text-white/80">{stat.value}</div>
                    <div className="text-[10px] text-slate-900/30 dark:text-white/30 mt-0.5">{stat.label}</div>
                  </div>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
