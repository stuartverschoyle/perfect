import { useState, useEffect } from 'react';
import { Search, Menu, X, ChevronDown } from 'lucide-react';
import SeoAnnotation from './SeoAnnotation';

const navLinks = [
  { label: 'Why Optimise', href: '#why-optimise' },
  { label: 'Step-by-Step', href: '#steps' },
  { label: 'What Improves', href: '#results' },
  { label: 'Maintenance', href: '#maintenance' },
  { label: 'Resources', href: '#resources' },
];

export default function ExampleNav() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <header
      className={`fixed top-11 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? 'bg-white/95 dark:bg-[#0a0a0a]/95 backdrop-blur-md border-b border-slate-200 dark:border-white/5' : 'bg-transparent'
      }`}
    >
      <nav className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" aria-label="Main navigation">
        <SeoAnnotation label="Nav" position="top-left">
          <p className="font-semibold text-slate-900 dark:text-white mb-1">Semantic Navigation</p>
          <p>The {'<nav>'} element with aria-label tells search engines this is the main site navigation. Use descriptive anchor text -- never "click here".</p>
          <p className="mt-2">Keep navigation links to 5-8 items. Each link passes PageRank to its target page (internal link equity).</p>
          <p className="mt-2 text-teal-600 dark:text-teal-400 font-medium">Structured navigation helps Google generate sitelinks in search results.</p>
        </SeoAnnotation>

        <div className="flex items-center justify-between h-20">
          <a href="#example" className="flex items-center gap-2.5 group" aria-label="Optimise homepage">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-400 to-emerald-500 flex items-center justify-center group-hover:shadow-lg group-hover:shadow-teal-500/20 transition-all">
              <Search size={18} className="text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">Optimise</span>
              <span className="text-[9px] tracking-[0.2em] text-slate-900/40 dark:text-white/40 uppercase -mt-0.5">Website Performance</span>
            </div>
          </a>

          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="px-4 py-2 text-[13px] font-medium text-slate-900/60 dark:text-white/60 hover:text-slate-900 dark:hover:text-white tracking-wide transition-colors relative group"
              >
                {link.label}
                <span className="absolute bottom-0 left-4 right-4 h-px bg-white/0 group-hover:bg-teal-400/40 transition-all" />
              </a>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-4">
            <div className="flex items-center gap-1 text-xs text-slate-900/40 dark:text-white/40 cursor-pointer hover:text-slate-900/60 dark:hover:text-white/60 transition-colors">
              EN <ChevronDown size={12} />
            </div>
            <a
              href="#resources"
              className="px-5 py-2.5 bg-teal-500 text-white text-xs font-semibold uppercase tracking-widest hover:bg-teal-400 transition-colors rounded-lg"
            >
              Free Audit
            </a>
          </div>

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden p-2 text-slate-900/70 dark:text-white/70 hover:text-slate-900 dark:hover:text-white transition-colors"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {mobileOpen && (
          <div className="lg:hidden absolute top-full left-0 right-0 bg-white/98 dark:bg-[#0a0a0a]/98 backdrop-blur-md border-b border-slate-200 dark:border-white/5 py-4 px-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="block py-3 text-sm font-medium text-slate-900/60 dark:text-white/60 hover:text-slate-900 dark:hover:text-white tracking-wide border-b border-slate-200 dark:border-white/5 transition-colors"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#resources"
              className="block mt-4 text-center px-5 py-3 bg-teal-500 text-white text-xs font-semibold uppercase tracking-widest rounded-lg"
            >
              Free Audit
            </a>
          </div>
        )}
      </nav>
    </header>
  );
}
