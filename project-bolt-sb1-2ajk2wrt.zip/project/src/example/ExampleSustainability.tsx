import { RefreshCw, Calendar, BarChart3, FileSearch } from 'lucide-react';
import SeoAnnotation from './SeoAnnotation';

export default function ExampleSustainability() {
  return (
    <section id="maintenance" className="relative py-24 sm:py-32 bg-slate-50 dark:bg-[#070707] scroll-mt-20 overflow-hidden">
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-teal-900/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <SeoAnnotation label="Internal Links" position="inline">
            <p className="font-semibold text-slate-900 dark:text-white mb-1">Internal Linking Strategy</p>
            <p>This section contains links to deeper pages ("/content-audit", "/technical-seo-checklist"). Internal links:</p>
            <ul className="mt-1.5 space-y-1">
              <li>- Pass PageRank (link equity) to important pages</li>
              <li>- Help Google discover and crawl your full site</li>
              <li>- Define your site's topical clusters</li>
              <li>- Reduce bounce rate by providing next steps</li>
            </ul>
            <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">Aim for 3-5 internal links per page. Use descriptive anchor text, never "read more" or "click here".</p>
          </SeoAnnotation>

          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-teal-500/20 bg-teal-500/5 mb-6 mt-3">
            <RefreshCw size={12} className="text-teal-600 dark:text-teal-400" />
            <span className="text-xs text-teal-600/80 dark:text-teal-400/80 tracking-wider uppercase">Ongoing Effort</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-light text-slate-900 dark:text-white tracking-tight mb-6">
            Maintenance That Keeps <span className="font-semibold">Rankings Growing</span>
          </h2>

          <p className="text-slate-900/50 dark:text-white/50 text-lg font-light leading-relaxed">
            Optimisation is never finished. Search engines constantly re-evaluate your site, competitors publish new content, and user expectations evolve. A regular maintenance schedule is what separates sites that rank from sites that used to rank.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Calendar, stat: 'Weekly', label: 'Performance Checks', desc: 'Monitor Core Web Vitals, crawl errors, and ranking changes in Search Console' },
            { icon: FileSearch, stat: 'Monthly', label: 'Content Audit', desc: 'Identify decaying content, update statistics, refresh outdated screenshots' },
            { icon: BarChart3, stat: 'Quarterly', label: 'Strategy Review', desc: 'Analyse competitor movements, revise keyword targets, update content calendar' },
            { icon: RefreshCw, stat: '6 Months', label: 'Major Refresh', desc: 'Rewrite underperforming pages, rebuild internal linking, update schema markup' },
          ].map((item) => (
            <div key={item.label} className="text-center p-6 bg-slate-100 dark:bg-white/[0.02] border border-slate-200 dark:border-white/[0.04] rounded-xl hover:bg-slate-100 dark:hover:bg-white/[0.04] hover:border-teal-500/10 transition-colors">
              <item.icon size={20} className="mx-auto text-teal-600/60 dark:text-teal-400/60 mb-4" />
              <div className="text-2xl font-light text-slate-900 dark:text-white mb-1">{item.stat}</div>
              <div className="text-xs font-semibold text-slate-900/60 dark:text-white/60 uppercase tracking-wider mb-2">{item.label}</div>
              <p className="text-[11px] text-slate-900/30 dark:text-white/30 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a
            href="#resources"
            className="inline-flex items-center gap-2 text-xs text-teal-600/60 dark:text-teal-400/60 hover:text-teal-600 dark:hover:text-teal-400 transition-colors tracking-wider uppercase font-medium"
          >
            Download Our Maintenance Calendar Template
          </a>
        </div>
      </div>
    </section>
  );
}
