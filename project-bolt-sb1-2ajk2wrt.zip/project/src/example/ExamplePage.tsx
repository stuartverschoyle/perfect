import { useEffect } from 'react';
import ExampleNav from './ExampleNav';
import ExampleHero from './ExampleHero';
import ExampleMemberships from './ExampleMemberships';
import ExampleFleet from './ExampleFleet';
import ExampleExperience from './ExampleExperience';
import ExampleSustainability from './ExampleSustainability';
import ExampleCTA from './ExampleCTA';
import ExampleFooter from './ExampleFooter';
import ExampleAnnotationBar from './ExampleAnnotationBar';
import AccessibilityToolbar from '../components/AccessibilityToolbar';

export default function ExamplePage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-[#0a0a0a] text-slate-900 dark:text-white font-sans">
      <ExampleAnnotationBar />
      <AccessibilityToolbar />
      <ExampleNav />
      <main>
        <ExampleHero />
        <ExampleMemberships />
        <ExampleFleet />
        <ExampleExperience />
        <ExampleSustainability />
        <ExampleCTA />
      </main>
      <ExampleFooter />
    </div>
  );
}
