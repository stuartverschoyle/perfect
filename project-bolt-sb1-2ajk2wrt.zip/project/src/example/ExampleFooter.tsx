import { Search } from 'lucide-react';
import SeoAnnotation from './SeoAnnotation';

const footerLinks = {
  Guide: ['Technical SEO', 'On-Page SEO', 'Page Speed', 'Content Strategy'],
  Tools: ['Site Audit', 'Speed Test', 'Schema Validator', 'SEO Checklist'],
  Learn: ['SEO Glossary', 'Case Studies', 'Video Tutorials', 'Newsletter'],
  Company: ['About Us', 'Contact', 'Write for Us', 'Careers'],
};

export default function ExampleFooter() {
  return (
    <footer className="relative border-t border-slate-200 dark:border-white/5 bg-slate-50 dark:bg-[#050505]">
      <SeoAnnotation label="Footer SEO" position="top-right">
        <p className="font-semibold text-slate-900 dark:text-white mb-1">Footer & Site Architecture</p>
        <p>The footer is inside a {'<footer>'} semantic element. Footers provide site-wide navigation that helps Google understand your full site architecture.</p>
        <p className="mt-1.5">Footer links should mirror your XML sitemap structure. They help distribute PageRank to important pages across the site.</p>
        <p className="mt-1.5">Include business details and legal links in the footer -- these build trust signals (E-E-A-T) for Google.</p>
        <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">The footer's structured link groups act as a mini-sitemap that search engines crawl on every page visit.</p>
      </SeoAnnotation>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-16">
          <div className="col-span-2 md:col-span-1">
            <a href="#example" className="flex items-center gap-2 mb-4" aria-label="Optimise homepage">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-teal-400 to-emerald-500 flex items-center justify-center">
                <Search size={14} className="text-white" />
              </div>
              <span className="text-sm font-bold tracking-tight text-slate-900 dark:text-white">Optimise</span>
            </a>
            <p className="text-xs text-slate-900/30 dark:text-white/30 leading-relaxed mb-4">
              The complete guide to website optimisation. Helping developers, designers, and copywriters build sites that rank.
            </p>
            <p className="text-xs text-slate-900/20 dark:text-white/20 leading-relaxed">
              Built as an example of a perfectly SEO-optimised page. Every element on this page follows best practices.
            </p>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="text-xs font-semibold text-slate-900/50 dark:text-white/50 uppercase tracking-wider mb-4">{category}</h4>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#example" className="text-xs text-slate-900/25 dark:text-white/25 hover:text-slate-900/60 dark:hover:text-white/60 transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="pt-8 border-t border-slate-200 dark:border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <span className="text-[11px] text-slate-900/15 dark:text-white/15">&copy; 2026 Optimise. All rights reserved.</span>
          </div>
          <div className="flex items-center gap-6">
            {['Privacy Policy', 'Terms of Service', 'Cookie Policy', 'Accessibility'].map((link) => (
              <a key={link} href="#example" className="text-[11px] text-slate-900/15 dark:text-white/15 hover:text-slate-900/40 dark:hover:text-white/40 transition-colors">
                {link}
              </a>
            ))}
          </div>
        </div>
      </div>

      <SeoAnnotation label="Schema" position="bottom-left">
        <p className="font-semibold text-slate-900 dark:text-white mb-1">JSON-LD Schema for This Page</p>
        <p>A real implementation would include this in the {'<head>'}:</p>
        <pre className="mt-2 p-2 bg-slate-950 rounded text-[10px] text-teal-300 overflow-x-auto">
{`{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Optimise a Website",
  "description": "A complete guide to improving speed, search rankings, and user experience.",
  "author": {
    "@type": "Person",
    "name": "Sarah Mitchell",
    "url": "https://optimise.dev/authors/sarah"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Optimise",
    "logo": "https://optimise.dev/logo.svg"
  },
  "datePublished": "2026-01-15",
  "dateModified": "2026-04-16"
}`}
        </pre>
        <p className="mt-2 text-teal-600 dark:text-teal-400 font-medium">Article schema helps Google display rich results with author info, dates, and featured snippets.</p>
      </SeoAnnotation>
    </footer>
  );
}
