import { TrendingUp, Search, MousePointerClick, DollarSign } from 'lucide-react';
import SeoAnnotation from './SeoAnnotation';

const benefits = [
  {
    icon: Search,
    title: 'Higher Search Rankings',
    description: 'Optimised websites consistently rank higher in Google. The top 3 results capture 55% of all organic clicks, making every position gained a significant traffic increase.',
  },
  {
    icon: MousePointerClick,
    title: 'Better User Experience',
    description: 'Fast-loading pages with clear navigation reduce bounce rates by up to 35%. Users stay longer, engage more, and are more likely to convert into customers.',
  },
  {
    icon: TrendingUp,
    title: 'More Organic Traffic',
    description: 'Organic search drives 53% of all website traffic. A well-optimised website attracts visitors 24/7 without the ongoing cost of paid advertising.',
  },
  {
    icon: DollarSign,
    title: 'Higher Conversion Rates',
    description: 'Every second of load time improvement increases conversions by 7%. Clear CTAs, readable copy, and trust signals turn visitors into leads and customers.',
  },
];

export default function ExampleExperience() {
  return (
    <section id="results" className="relative py-24 sm:py-32 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="relative">
              <SeoAnnotation label="First Paragraph" position="inline">
                <p className="font-semibold text-slate-900 dark:text-white mb-1">First Paragraph & AEO</p>
                <p>The opening paragraph of each section should directly answer a potential search query. This is critical for Answer Engine Optimization.</p>
                <p className="mt-1.5">Here, the first sentence answers "What happens when you optimise a website?" -- a question Google may surface as a featured snippet.</p>
                <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">Write the first 160 characters as if it will be the search result snippet. It often will be.</p>
              </SeoAnnotation>
            </div>

            <span className="block text-xs text-slate-900/30 dark:text-white/30 tracking-[0.3em] uppercase mb-3 mt-3">The Results</span>
            <h2 className="text-3xl sm:text-4xl font-light text-slate-900 dark:text-white tracking-tight mb-6">
              What Improves When You <span className="font-semibold">Optimise</span>
            </h2>

            <p className="text-slate-900/50 dark:text-white/50 text-base leading-relaxed mb-10 font-light">
              Website optimisation delivers measurable results across traffic, engagement, and revenue. The data consistently shows that faster, better-structured websites outperform their competitors in every meaningful metric.
            </p>

            <div className="space-y-6">
              {benefits.map((b) => (
                <div key={b.title} className="group flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-teal-500/5 border border-teal-500/10 flex items-center justify-center shrink-0 group-hover:bg-teal-500/10 transition-colors">
                    <b.icon size={16} className="text-teal-600/60 dark:text-teal-400/60" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-1">{b.title}</h3>
                    <p className="text-xs text-slate-900/40 dark:text-white/40 leading-relaxed">{b.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <SeoAnnotation label="Image Ratio" position="top-right">
              <p className="font-semibold text-slate-900 dark:text-white mb-1">Image-to-Copy Ratio</p>
              <p>This section demonstrates the ideal balance: 40-60% copy, 40-60% visual. Google rewards pages that mix media types.</p>
              <p className="mt-1.5">The image complements the text content -- it doesn't replace it. Search engines can't fully "read" images, so the text must carry the SEO weight.</p>
              <p className="mt-1.5 text-teal-600 dark:text-teal-400 font-medium">Pages with images get 94% more views. But text-heavy pages rank better. Strike the balance.</p>
            </SeoAnnotation>

            <div className="relative">
              <img
                src="https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=800&h=1000&fit=crop"
                alt="Website analytics dashboard showing traffic growth and improved search rankings after optimisation"
                width={800}
                height={1000}
                loading="lazy"
                className="w-full rounded-xl object-cover aspect-[4/5]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-white dark:from-[#0a0a0a] via-transparent to-transparent rounded-xl" />

              <div className="absolute bottom-6 left-6 right-6">
                <div className="flex items-center gap-3 p-4 bg-white/60 dark:bg-black/60 backdrop-blur-md rounded-xl border border-slate-200 dark:border-white/5">
                  <div className="text-center flex-1">
                    <div className="text-2xl font-light text-slate-900 dark:text-white">53%</div>
                    <div className="text-[10px] text-slate-900/40 dark:text-white/40 tracking-wider uppercase mt-0.5">Organic Traffic Share</div>
                  </div>
                  <div className="w-px h-10 bg-slate-200 dark:bg-white/10" />
                  <div className="text-center flex-1">
                    <div className="text-2xl font-light text-slate-900 dark:text-white">7%</div>
                    <div className="text-[10px] text-slate-900/40 dark:text-white/40 tracking-wider uppercase mt-0.5">Conv. Lift Per Second</div>
                  </div>
                  <div className="w-px h-10 bg-slate-200 dark:bg-white/10" />
                  <div className="text-center flex-1">
                    <div className="text-2xl font-light text-slate-900 dark:text-white">14.6%</div>
                    <div className="text-[10px] text-slate-900/40 dark:text-white/40 tracking-wider uppercase mt-0.5">SEO Close Rate</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
