import { Globe, Tag, Share2, Link2, FileCode } from 'lucide-react';
import InfoTooltip from '../components/InfoTooltip';
import CodeBlock from '../components/CodeBlock';
import SeoSection from '../components/SeoSection';

export default function MetaSection() {
  return (
    <SeoSection id="meta" className="space-y-8">
      <div className="flex items-start gap-3">
        <div className="p-2.5 rounded-xl bg-sky-100 dark:bg-sky-500/10 text-sky-500 dark:text-sky-400 shrink-0">
          <Globe size={24} />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Meta Data & Head Tags</h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1">The invisible foundation that tells search engines exactly what your page is about.</p>
        </div>
      </div>

      {/* Title Tag */}
      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/50 p-5">
        <div className="flex items-center gap-2 mb-3">
          <Tag size={18} className="text-sky-500 dark:text-sky-400" />
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Title Tag</h3>
          <InfoTooltip title="Title Tag Best Practices">
            <ul className="space-y-2">
              <li><strong className="text-slate-900 dark:text-white">Length:</strong> Keep between 50-60 characters. Google typically displays the first 50-60 characters. Anything longer gets truncated with an ellipsis.</li>
              <li><strong className="text-slate-900 dark:text-white">Placement:</strong> Put your primary keyword near the beginning of the title for maximum SEO weight.</li>
              <li><strong className="text-slate-900 dark:text-white">Uniqueness:</strong> Every page on your site must have a unique title tag. Duplicate titles confuse search engines and dilute ranking signals.</li>
              <li><strong className="text-slate-900 dark:text-white">Branding:</strong> Include your brand name at the end, separated by a pipe (|) or dash (-). Example: "Primary Keyword - Secondary Keyword | Brand"</li>
              <li><strong className="text-slate-900 dark:text-white">Avoid:</strong> Keyword stuffing, ALL CAPS, and generic titles like "Home" or "Welcome".</li>
              <li><strong className="text-slate-900 dark:text-white">CTR Impact:</strong> The title tag is the clickable headline in search results. A compelling title directly increases your click-through rate.</li>
            </ul>
          </InfoTooltip>
        </div>
        <div className="bg-slate-100 dark:bg-slate-900 rounded-lg p-4 border border-slate-200 dark:border-slate-700/30">
          <div className="text-xs text-slate-500 mb-1">Browser Tab Preview</div>
          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 rounded-md px-3 py-2">
            <div className="w-4 h-4 rounded bg-sky-500/20 shrink-0" />
            <span className="text-sm text-slate-900 dark:text-white truncate">How to Build the Perfect SEO Web Page | SEO Guide 2026</span>
          </div>
          <div className="mt-3 text-xs text-slate-500">Character count: <span className="text-emerald-600 dark:text-emerald-400 font-mono">56 / 60</span></div>
        </div>
        <CodeBlock
          language="html"
          code={`<title>How to Build the Perfect SEO Web Page | SEO Guide 2026</title>`}
        />
      </div>

      {/* Meta Description */}
      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/50 p-5">
        <div className="flex items-center gap-2 mb-3">
          <FileCode size={18} className="text-sky-500 dark:text-sky-400" />
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Meta Description</h3>
          <InfoTooltip title="Meta Description Best Practices">
            <ul className="space-y-2">
              <li><strong className="text-slate-900 dark:text-white">Length:</strong> Keep between 150-160 characters. Google truncates descriptions beyond ~155 characters on desktop and ~120 on mobile.</li>
              <li><strong className="text-slate-900 dark:text-white">Purpose:</strong> This is your "ad copy" in search results. It doesn't directly affect rankings but massively impacts click-through rates.</li>
              <li><strong className="text-slate-900 dark:text-white">Keywords:</strong> Include your target keyword naturally. Google bolds matching search terms in the description, making your result stand out.</li>
              <li><strong className="text-slate-900 dark:text-white">Action-oriented:</strong> Use a call-to-action like "Learn how...", "Discover...", "Find out..."</li>
              <li><strong className="text-slate-900 dark:text-white">Uniqueness:</strong> Every page needs a unique meta description. Duplicates can trigger Google to auto-generate one instead.</li>
              <li><strong className="text-slate-900 dark:text-white">Avoid:</strong> Double quotes (they get cut off), generic descriptions, and keyword stuffing.</li>
            </ul>
          </InfoTooltip>
        </div>
        <div className="bg-slate-100 dark:bg-slate-900 rounded-lg p-4 border border-slate-200 dark:border-slate-700/30">
          <div className="text-xs text-slate-500 mb-2">Google Search Preview</div>
          <div className="space-y-1">
            <div className="text-sm text-sky-500 dark:text-sky-400 hover:underline cursor-pointer">How to Build the Perfect SEO Web Page | SEO Guide 2026</div>
            <div className="text-xs text-emerald-600 dark:text-emerald-400 font-mono">https://example.com/seo-guide/perfect-web-page</div>
            <div className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">Learn every element of a perfectly optimized web page for SEO. From meta tags and heading structure to image optimization and schema markup -- your complete guide.</div>
          </div>
          <div className="mt-3 text-xs text-slate-500">Character count: <span className="text-emerald-600 dark:text-emerald-400 font-mono">153 / 160</span></div>
        </div>
        <CodeBlock
          language="html"
          code={`<meta name="description" content="Learn every element of a perfectly optimized web page for SEO. From meta tags and heading structure to image optimization and schema markup -- your complete guide." />`}
        />
      </div>

      {/* Open Graph */}
      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/50 p-5">
        <div className="flex items-center gap-2 mb-3">
          <Share2 size={18} className="text-sky-500 dark:text-sky-400" />
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Open Graph Tags</h3>
          <InfoTooltip title="Open Graph (OG) Tags">
            <ul className="space-y-2">
              <li><strong className="text-slate-900 dark:text-white">What:</strong> Open Graph protocol controls how your page appears when shared on social media (Facebook, LinkedIn, Twitter/X, Slack, etc.).</li>
              <li><strong className="text-slate-900 dark:text-white">og:title:</strong> Can differ from your page title. Optimize for social engagement rather than keywords.</li>
              <li><strong className="text-slate-900 dark:text-white">og:description:</strong> A compelling social-specific description. Can be more conversational than your meta description.</li>
              <li><strong className="text-slate-900 dark:text-white">og:image:</strong> The most important OG tag. Ideal size: 1200x630px. This is what makes shared links visually compelling.</li>
              <li><strong className="text-slate-900 dark:text-white">og:type:</strong> Usually "website" or "article". Helps platforms understand your content type.</li>
              <li><strong className="text-slate-900 dark:text-white">og:url:</strong> The canonical URL of your page. Prevents duplicate content signals from social shares.</li>
              <li><strong className="text-slate-900 dark:text-white">Twitter/X:</strong> Use twitter:card, twitter:title, twitter:description, and twitter:image for X-specific control.</li>
            </ul>
          </InfoTooltip>
        </div>
        <div className="bg-slate-100 dark:bg-slate-900 rounded-lg p-4 border border-slate-200 dark:border-slate-700/30">
          <div className="text-xs text-slate-500 mb-2">Social Share Preview</div>
          <div className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden max-w-sm">
            <div className="bg-slate-200 dark:bg-slate-700 h-40 flex items-center justify-center text-slate-500 text-sm">
              <div className="text-center">
                <Share2 size={32} className="mx-auto mb-2 opacity-50" />
                og:image (1200 x 630px)
              </div>
            </div>
            <div className="p-3 bg-slate-100 dark:bg-slate-800">
              <div className="text-xs text-slate-500 mb-0.5">example.com</div>
              <div className="text-sm font-medium text-slate-900 dark:text-white">The Perfect SEO Web Page -- A Complete Guide</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Everything you need to know about building a web page that ranks.</div>
            </div>
          </div>
        </div>
        <CodeBlock
          language="html"
          code={`<meta property="og:title" content="The Perfect SEO Web Page - A Complete Guide" />
<meta property="og:description" content="Everything you need to know about building a web page that ranks." />
<meta property="og:image" content="https://example.com/images/seo-guide-og.jpg" />
<meta property="og:url" content="https://example.com/seo-guide/perfect-web-page" />
<meta property="og:type" content="article" />

<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="The Perfect SEO Web Page - A Complete Guide" />
<meta name="twitter:image" content="https://example.com/images/seo-guide-og.jpg" />`}
        />
      </div>

      {/* Canonical URL */}
      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/50 p-5">
        <div className="flex items-center gap-2 mb-3">
          <Link2 size={18} className="text-sky-500 dark:text-sky-400" />
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Canonical URL</h3>
          <InfoTooltip title="Canonical URL" variant="warning">
            <ul className="space-y-2">
              <li><strong className="text-slate-900 dark:text-white">Purpose:</strong> Tells search engines which version of a page is the "master" copy. Prevents duplicate content penalties.</li>
              <li><strong className="text-slate-900 dark:text-white">When needed:</strong> If your content appears at multiple URLs (with/without www, HTTP/HTTPS, query parameters, paginated pages), canonical tags consolidate ranking signals to one URL.</li>
              <li><strong className="text-slate-900 dark:text-white">Self-referencing:</strong> Every page should have a self-referencing canonical tag, even if there are no duplicates. This is considered best practice.</li>
              <li><strong className="text-slate-900 dark:text-white">Cross-domain:</strong> You can point canonical to a different domain if content is syndicated. This gives ranking credit to the original source.</li>
              <li><strong className="text-slate-900 dark:text-white">Common mistake:</strong> Forgetting canonical tags on paginated content (page 1, page 2, etc.), leading search engines to see them as duplicate content.</li>
            </ul>
          </InfoTooltip>
        </div>
        <CodeBlock
          language="html"
          code={`<link rel="canonical" href="https://example.com/seo-guide/perfect-web-page" />`}
        />
        <div className="flex items-start gap-2 mt-3 p-3 rounded-lg bg-amber-50 dark:bg-amber-500/5 border border-amber-300 dark:border-amber-500/20">
          <span className="text-amber-600 dark:text-amber-400 text-sm mt-0.5">!</span>
          <p className="text-sm text-amber-700 dark:text-amber-300/80">Missing canonical tags is one of the most common SEO mistakes. Always include one, even on pages with no duplicates.</p>
        </div>
      </div>

      {/* Robots Meta */}
      <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/50 p-5">
        <div className="flex items-center gap-2 mb-3">
          <FileCode size={18} className="text-sky-500 dark:text-sky-400" />
          <h3 className="text-lg font-semibold text-slate-900 dark:text-white">Robots Meta Tag</h3>
          <InfoTooltip title="Robots Meta Tag">
            <ul className="space-y-2">
              <li><strong className="text-slate-900 dark:text-white">index/noindex:</strong> Controls whether search engines add this page to their index. Use "noindex" for pages like thank-you pages, internal search results, or staging environments.</li>
              <li><strong className="text-slate-900 dark:text-white">follow/nofollow:</strong> Controls whether search engines follow links on the page. "nofollow" means links won't pass PageRank.</li>
              <li><strong className="text-slate-900 dark:text-white">Default behavior:</strong> If no robots tag is present, search engines default to "index, follow" -- meaning the page is indexed and all links are followed.</li>
              <li><strong className="text-slate-900 dark:text-white">max-snippet:</strong> Controls the maximum text length of a search snippet. Use "max-snippet:-1" for unlimited.</li>
              <li><strong className="text-slate-900 dark:text-white">max-image-preview:</strong> Controls the size of image previews in search results. "large" is recommended for most pages.</li>
            </ul>
          </InfoTooltip>
        </div>
        <CodeBlock
          language="html"
          code={`<!-- Allow indexing and link following (default, but explicit is better) -->
<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large" />

<!-- Block indexing (for pages you don't want in search results) -->
<meta name="robots" content="noindex, nofollow" />`}
        />
      </div>
    </SeoSection>
  );
}
