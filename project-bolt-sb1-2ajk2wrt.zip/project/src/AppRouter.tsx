import { useState, useEffect } from 'react';
import App from './App';
import ExamplePage from './example/ExamplePage';

export default function AppRouter() {
  const [route, setRoute] = useState(window.location.hash || '#guide');

  useEffect(() => {
    const onHash = () => setRoute(window.location.hash || '#guide');
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  if (route === '#example') {
    return <ExamplePage />;
  }

  return <App />;
}
